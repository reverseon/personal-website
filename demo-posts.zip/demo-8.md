<!---META
title: Ruby and Footnote Feature Demo
subtitle: Testing custom markdown syntax for the site
slug: ruby-footnote-demo
published_unix: 1714120000
categories: [Demo, Testing]
tags: [Ruby, Footnote, Custom]
--->

# Demonstration of Custom Markdown

Here we show off the Ruby feature for furigana:

Welcome to my site! Or in Japanese: RUBY{歓迎|かん.げい}

And here is a Footnote:
<!--Footnote RUBY{歓迎|かん.げい} (kange) means "welcome" or "a warm reception" in Japanese. -->
