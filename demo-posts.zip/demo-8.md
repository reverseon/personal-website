<!---META
title: Ruby and TLN Feature Demo
subtitle: Testing custom markdown syntax for the site
slug: ruby-tln-demo
published_unix: 1714120000
categories: [Demo, Testing]
tags: [Ruby, TLN, Custom]
--->

# Demonstration of Custom Markdown

Here we show off the Ruby feature for furigana:

Welcome to my site! Or in Japanese: RUBY{歓迎|かん.げい}

And here is a Translator's Note:
<!--TLN This is a translator's note to explain that the word above means welcome. -->
